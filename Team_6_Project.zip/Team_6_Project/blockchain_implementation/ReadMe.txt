Installation:
pip install -r requirements.txt

Run:
Step 1: Run Servers:
Run in separate terminals the following commands
python main.py 127.0.0.1 5000
python main.py 127.0.0.1 5001
python main.py 127.0.0.1 5002
python main.py 127.0.0.1 5003


Step 2: Run Simulation
python simulation.py 30

